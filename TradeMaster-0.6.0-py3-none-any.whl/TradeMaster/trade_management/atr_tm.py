from TradeMaster.helpers.indicators import calculate_atr


class ATR_RR_TradeManagement:
    def __init__(self, strategy, risk_reward_ratio, atr_multiplier, atr_period):
        """
        Initialize the ATR_RR_TradeManagement class.
        A reference to Strategy class object is included to access all of its parameters
        """
        self.strategy = strategy
        self.risk_reward_ratio = risk_reward_ratio
        self.atr_multiplier = atr_multiplier
        self.atr_period = atr_period
        

    def calculate_tp_sl(self, direction):
        """
        Calculate the stop loss and take profit levels based on ATR and R:R ratio.

        :param df: pandas DataFrame, must contain 'High', 'Low', and 'Close' columns
        :param direction: str, either 'buy' or 'sell'
        :return: tuple, stop loss and take profit prices
        """
        entry_price = self.strategy.data.df['Close'].iloc[-1]
        # entry_price = round(entry_price,3)
        atr = calculate_atr(self.strategy.data.df, self.atr_period)
        # print("ATR",atr)
        risk = atr * self.atr_multiplier
        # print("Risk",risk)
        # print("closing price",entry_price)
        # print(f'Atr={atr}')
        if direction.lower() == 'buy':
            stop_loss = entry_price - risk
            take_profit = entry_price + (risk * self.risk_reward_ratio)
        elif direction.lower() == 'sell':
            stop_loss = entry_price + risk
            take_profit = entry_price - (risk * self.risk_reward_ratio)
        else:
            raise ValueError("Invalid direction. Must be 'buy' or 'sell'.")
        
        # print(f'Entry_price={entry_price}, Risk={risk}, Direction={direction}, Risk-to-reward-ratio={self.risk_to_reward_ratio}')
        # print("Stop loss b4 rounding", stop_loss)
        stop_loss = round(stop_loss, 5)
        take_profit = round(take_profit,5)

        # print("Close price")
        # if take_profit <0:
        # print(f'Take Profit = {take_profit}, Stop Loss = {stop_loss} Close price {entry_price}')
        #     print(f'Entry_price={entry_price}, Risk={risk}, Direction={direction}, Risk-to-reward-ratio={self.risk_to_reward_ratio}')
        #     take_profit = 0.00001
        return stop_loss, take_profit