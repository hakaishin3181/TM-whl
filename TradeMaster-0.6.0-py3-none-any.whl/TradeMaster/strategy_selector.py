class StrategySelector:
    def __init__(self, trade_management_strategy, risk_management_strategy):
        self.trade_management_strategy = trade_management_strategy
        self.risk_management_strategy = risk_management_strategy
