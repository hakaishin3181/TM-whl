from abc import ABC, abstractmethod

class BaseRiskManagement(ABC):
    def __init__(self,initial_risk_per_trade, initial_capital):
        self.initial_capital = initial_capital
        self.initial_risk_per_trade = initial_risk_per_trade
        

