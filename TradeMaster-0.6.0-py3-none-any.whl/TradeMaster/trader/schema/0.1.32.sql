ALTER TABLE
	"IbTrade"
ADD
	COLUMN "account_allocation_name" TEXT;