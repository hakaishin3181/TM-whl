ALTER TABLE
	"IbOrder"
ADD
	COLUMN "account" TEXT;

ALTER TABLE
	"IbOrder"
ADD
	COLUMN "totalSize" FLOAT;