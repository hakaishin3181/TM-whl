import pandas as pd
import talib as ta

def calculate_atr(df, atr_period):
    """
    Calculate the Average True Range (ATR) from the DataFrame.

    :param df: pandas DataFrame, must contain 'High', 'Low', and 'Close' columns
    :param period: int, the period for ATR calculation
    :return: float, the ATR value
    """
    # df['High-Low'] = df['High'] - df['Low']
    # df['High-Close'] = abs(df['High'] - df['Close'].shift())
    # df['Low-Close'] = abs(df['Low'] - df['Close'].shift())

    # tr = df[['High-Low', 'High-Close', 'Low-Close']].max(axis=1)
    # atr = tr.rolling(window=period).mean().iloc[-1]
    atr = ta.ATR(df['High'],df['Low'],df['Close'],atr_period)
    # print("DF is")
    # print(df)
    # print(atr)
    # print(atr)
    return atr.iloc[-1]
