BROKER_CONFIG = {
    'mt5': {
        'login': 'your_login',
        'password': 'your_password',
        'server': 'your_server',
    },
    'binance': {
        'api_key': 'your_api_key',
        'api_secret': 'your_api_secret',
    },
    # Add other brokers here
}
