from datetime import datetime
from pybit.unified_trading import HTTP
import pandas as pd

class BybitBrokerWrapper:
    def connect(self, api_key: str, api_secret: str, testnet: bool = False):
        self.testnet = testnet
        self.client = HTTP(
            api_key= api_key,
            api_secret= api_secret,
            testnet=testnet
        )
        
    def convert_to_ms(self, time):
        dt_obj = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
        start_time_ms = int(dt_obj.timestamp() * 1000)  
        
    def convert_ms_to_datetime(self, ms):
        seconds = (int)(ms) / 1000.0
        datetime_obj = datetime.utcfromtimestamp(seconds)
        return datetime_obj.strftime('%Y-%m-%d %H:%M:%S')
        
    def fetch_data(self, category, symbol, timeframe, start, end):
        # Returns past 200 candle data only independent of start and end?
        start = self.convert_to_ms(start)
        end = self.convert_to_ms(end)
        data = self.client.get_mark_price_kline(
            category=category,
            symbol=symbol,
            interval=timeframe,
            start=start,
            end=end,
        )['result']['list']
        for row in data:
            row[0] = self.convert_ms_to_datetime(row[0])
        df = pd.DataFrame(data)
        df.columns = ['Timestamp', 'Open', 'High', 'Low', 'Close']
        df.set_index('Timestamp', inplace=True)
        df.sort_index(inplace=True)
        return df

    def get_balance(self, account_type = "UNIFIED"):
        return self.client.get_wallet_balance(
            accountType=account_type
        )['result']

    def place_order(self):
        pass

    def get_order(self):
        pass

    def cancel_order(self):
        pass

    def get_open_orders(self):
        pass

    def get_trade_history(self):
        pass

    def get_market_data(self, symbol):
        pass

    def get_positions(self, category, symbol):
        return self.client.get_positions(
            category=category,
            symbol=symbol,
        )['result']['list'][0]

    def get_account_info(self):
        pass
        
    def get_tickers(self):
        result = self.client.get_tickers(
                category="linear").get('result')['list']

        tickers = [asset['symbol'] for asset in result if asset['symbol'].endswith('USDT')]
        print(tickers)
        

    def get_orderbook(self, category: str, symbol: str):
        """
        Retrieve the order book for a specified symbol and category.
        """
        return self.client.get_orderbook(category=category, symbol=symbol)

    def place_order(self, category: str, symbol: str, side: str, order_type: str, qty: float, price: float = None, **kwargs):
        """
        Place an order with the specified parameters.
        """
        order_params = {
            "category": category,
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "qty": qty
        }
        if price is not None:
            order_params["price"] = price
        order_params.update(kwargs)
        return self.client.place_order(**order_params)

    def cancel_order(self, category: str, symbol: str, order_id: str):
        """
        Cancel an existing order by order ID.
        """
        return self.client.cancel_order(category=category, symbol=symbol, orderId=order_id)

    def get_open_orders(self, category: str, symbol: str = None):
        """
        Retrieve all open orders for a specified category and symbol.
        """
        return self.client.get_open_orders(category=category, symbol=symbol)

    def get_order_history(self, category: str, symbol: str = None, **kwargs):
        """
        Retrieve the order history for a specified category and symbol.
        """
        return self.client.get_order_history(category=category, symbol=symbol, **kwargs)

    def get_wallet_balance(self, account_type: str = "UNIFIED"):
        """
        Retrieve the wallet balance for the specified account type.
        """
        return self.client.get_wallet_balance(accountType=account_type)
                    
    
# def convert_to_datetime(time):
#     time = (int)(time)
#     timestamp_seconds = time / 1000
#     dt_obj = datetime.utcfromtimestamp(timestamp_seconds)          

if __name__ == '__main__':
    api_key = '8GI5gXmTcHlKnCNbM1'
    api_secret_key = 'ZwFq0aYBIneRraxO12wdcE2HMwkogqRLXOUS'
    broker = BybitBrokerWrapper()
    broker.connect(api_key, api_secret_key, True)    
    # broker.get_tickers()
    # print(broker.get_wallet_balance_testnet())
    # print(broker.get_positions('linear', 'BTCUSDT'))
    # broker.place_order(category='linear', symbol='BTCUSDT', side='Buy',order_type='Market',qty=0.001)
    # print(broker.get_positions('linear', 'BTCUSDT'))
    data = broker.fetch_data("linear", "BTCUSDT", "D", "2024-12-05 10:30:00", "2025-01-01 10:30:00")
    print(data) 
    print(broker.get_balance())